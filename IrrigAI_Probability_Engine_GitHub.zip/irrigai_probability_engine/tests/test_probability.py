import unittest
import pandas as pd

from probability import (
    conditional_prob,
    irrigation_decision,
    joint_prob,
    marginal_prob,
)


class ProbabilityFunctionTests(unittest.TestCase):
    def setUp(self):
        self.df = pd.DataFrame({
            "soil_cat": ["Dry", "Dry", "Wet", "Moderate"],
            "rain_cat": ["None", "Light", "Heavy", "None"],
            "soil_next_dry": [1, 0, 0, 1],
        })

    def test_joint_probability(self):
        p, count = joint_prob(self.df, "Dry", "None")
        self.assertEqual(count, 1)
        self.assertEqual(p, 0.25)

    def test_marginal_probability(self):
        p, count = marginal_prob(self.df, "soil_cat", "Dry")
        self.assertEqual(count, 2)
        self.assertEqual(p, 0.5)

    def test_conditional_probability(self):
        p, event_count, support = conditional_prob(
            self.df, {"soil_next_dry": 1}, {"soil_cat": "Dry"}
        )
        self.assertEqual((event_count, support), (1, 2))
        self.assertEqual(p, 0.5)

    def test_zero_denominator_is_undefined(self):
        p, event_count, support = conditional_prob(
            self.df, {"soil_next_dry": 1}, {"soil_cat": "Wet", "rain_cat": "None"}
        )
        self.assertIsNone(p)
        self.assertEqual((event_count, support), (0, 0))

    def test_decision_rule(self):
        self.assertEqual(irrigation_decision(0.8, 2, 10)["decision"], "IRRIGATE NOW")
        self.assertEqual(irrigation_decision(0.5, 2, 10)["decision"], "DELAY & RE-CHECK")
        self.assertEqual(irrigation_decision(0.1, 2, 10)["decision"], "DON'T IRRIGATE")
        self.assertEqual(irrigation_decision(None, 2, 10)["decision"], "INSUFFICIENT_DATA")


if __name__ == "__main__":
    unittest.main()
